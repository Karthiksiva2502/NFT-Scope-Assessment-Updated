# Debug utility functions for the NFT Risk Assessment tool
import streamlit as st
import json

def add_debug_button():
    """Adds debug information display to the Streamlit app"""
    with st.expander("Debug Information"):
        st.info("This section shows debug information for developers")
        
        st.subheader("Session State")
        # Filter out large objects that might clutter the display
        filtered_state = {k: v for k, v in st.session_state.items() 
                         if not isinstance(v, (list, dict)) or k in ['current_context']}
        
        st.json(filtered_state)
        
        st.subheader("Current Context")
        st.json(st.session_state.get('current_context', {}))
        
        if st.button("Clear Session State"):
            for key in list(st.session_state.keys()):
                # Keep only essential keys
                if key not in ['ctx_project_type_sidebar_global', 'api_key_input_global']:
                    del st.session_state[key]
            st.success("Session state cleared!")
            st.rerun()
