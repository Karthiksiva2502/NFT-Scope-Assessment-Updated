# Functions for Chroma DB interactions and embedding generation
import chromadb
from chromadb.utils import embedding_functions
import openai
import uuid
import os
import time
import requests
import backoff  # Add this import
import logging  # Add this import

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Configuration ---
CHROMA_DB_PATH = "./chroma_db"
COLLECTION_NAME = "requirements_assessments"
EMBEDDING_MODEL = "text-embedding-3-small"  # Updated to the newer model
DEFAULT_SIMILARITY_THRESHOLD = 0.7 # Default distance threshold (lower means more similar, higher means less strict)
DEFAULT_N_RESULTS = 5 # Default number of results to fetch
MAX_RETRIES = 3  # Maximum number of retries for API calls

# --- ChromaDB Client Initialization ---
# Ensure the directory exists
os.makedirs(CHROMA_DB_PATH, exist_ok=True)

# Use PersistentClient for saving data to disk
client = chromadb.PersistentClient(path=CHROMA_DB_PATH)

# --- Connectivity Check ---
def check_openai_connectivity(api_key):
    """
    Check if we can connect to OpenAI API.
    Raises openai.AuthenticationError or ConnectionError on failure.
    Returns True on success.
    """
    try:
        client = openai.OpenAI(api_key=api_key)
        client.models.list() # A lightweight call to check connectivity and auth
        logger.info("OpenAI API connectivity and authentication successful.")
        return True
    except openai.APIConnectionError as e:
        logger.error(f"Cannot connect to OpenAI API - network connectivity issue: {e}")
        raise ConnectionError(f"Failed to connect to OpenAI. Please check your network connection and firewall settings: {str(e)}")
    except openai.AuthenticationError as e:
        logger.error(f"OpenAI API authentication failed - check API key: {e}")
        raise # Re-raise the original AuthenticationError to be caught specifically
    except Exception as e: # Catch any other OpenAI or general exceptions during the check
        logger.error(f"OpenAI API check failed with an unexpected error: {e}")
        # Wrap in a more generic exception if it's not already an OpenAI one
        raise Exception(f"An unexpected error occurred during OpenAI API check: {str(e)}")

# --- Embedding Function ---
# Note: API key is passed dynamically now
def get_openai_embedding_function(api_key):
    """Returns a ChromaDB embedding function configured with the provided API key."""
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    # This uses Chroma's helper, which internally handles the OpenAI client setup
    return embedding_functions.OpenAIEmbeddingFunction(
        api_key=api_key,
        model_name=EMBEDDING_MODEL
    )

# --- Collection Handling ---
def get_or_create_collection(api_key):
    """
    Gets or creates the ChromaDB collection with the appropriate embedding function.
    Propagates exceptions from check_openai_connectivity.
    """
    check_openai_connectivity(api_key) # Will raise AuthenticationError or ConnectionError on failure
        
    openai_ef = get_openai_embedding_function(api_key)
    collection = client.get_or_create_collection(
        name=COLLECTION_NAME,
        embedding_function=openai_ef,
        metadata={"hnsw:space": "cosine"} # Use cosine distance for similarity
    )
    return collection

# Define exponential backoff for API calls
@backoff.on_exception(
    backoff.expo,
    (openai.RateLimitError, openai.APIConnectionError, requests.exceptions.RequestException),
    max_tries=MAX_RETRIES
)
def _generate_embedding_with_retry(text, api_key):
    """Internal function to generate embedding with retry logic."""
    client = openai.OpenAI(api_key=api_key)
    response = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=[text]  # API expects a list
    )
    return response.data[0].embedding

# --- Core Functions ---
def generate_embedding(text, api_key):
    """
    Generates embedding for a given text using OpenAI with retry logic.
    Propagates exceptions from check_openai_connectivity or embedding generation.
    """
    if not api_key:
        raise ValueError("OpenAI API Key is required for embedding generation.")
    
    check_openai_connectivity(api_key) # Initial check, raises on failure

    try:
        return _generate_embedding_with_retry(text, api_key)
    except openai.AuthenticationError: # If auth fails specifically during embedding call
        logger.error("Authentication error during embedding generation attempt.")
        raise # Re-raise to be caught by app.py
    except openai.APIConnectionError as e: # Should be caught by backoff, but as a fallback
        logger.error(f"Connection error during embedding generation (post-retry or unhandled by backoff): {e}")
        raise ConnectionError(f"Failed to connect to OpenAI for embedding after retries: {str(e)}")
    except openai.RateLimitError as e:
        logger.error(f"Rate limit exceeded during embedding generation: {e}")
        raise Exception(f"OpenAI rate limit exceeded during embedding: {str(e)}. Please try again later.")
    except Exception as e: # Catch-all for other unexpected errors
        logger.error(f"Unexpected error generating embedding: {e}")
        raise Exception(f"An unexpected error occurred while generating embedding: {str(e)}")

# Update function signature to accept project_name
def add_assessment(collection, requirement_text, embedding, risk, reasoning, recommendations, impact, project_name):
    """Adds a new assessment to the ChromaDB collection."""
    doc_id = str(uuid.uuid4())
    timestamp = int(time.time())
    metadata = {
        "requirement_text": requirement_text,
        "risk": risk,
        "reasoning": reasoning,
        "recommendations": recommendations,
        "impact": impact,
        "project_name": project_name, # Add project_name here
        "status": "Pending", # Changed from 'approved': False
        "comments": "",
        "timestamp": timestamp,
        "id": doc_id # Store the ID also in metadata for easier retrieval if needed
    }
    try:
        collection.add(
            documents=[requirement_text], # Chroma stores the original text here
            embeddings=[embedding],
            metadatas=[metadata],
            ids=[doc_id]
        )
        print(f"Added assessment with ID: {doc_id}")
        return doc_id
    except Exception as e:
        print(f"Error adding assessment to Chroma: {e}")
        return None

def find_similar_requirements(collection, embedding, n_results=DEFAULT_N_RESULTS, custom_threshold=DEFAULT_SIMILARITY_THRESHOLD):
    """
    Finds similar requirements in the collection based on embedding.
    Args:
        collection: The ChromaDB collection object.
        embedding: The query embedding.
        n_results (int): The number of results to retrieve from ChromaDB.
        custom_threshold (float): The distance threshold for similarity (distance < threshold).
    """
    if embedding is None:
        return None
    try:
        results = collection.query(
            query_embeddings=[embedding],
            n_results=n_results, # Use the provided n_results
            include=['metadatas', 'distances'] # Include metadata and distance
        )

        similar_docs = []
        if results and results.get('ids') and results['ids'][0]:
            for i, doc_id in enumerate(results['ids'][0]):
                distance = results['distances'][0][i]
                # Use the custom_threshold for filtering
                if distance < custom_threshold:
                    metadata = results['metadatas'][0][i]
                    similar_docs.append({
                        "id": doc_id,
                        "distance": distance,
                        "metadata": metadata
                    })
            # Sort by distance (most similar first) - this is already implicitly done by Chroma for vector search
            # but explicit sort ensures if we change n_results logic later.
            similar_docs.sort(key=lambda x: x['distance'])
        return similar_docs
    except Exception as e:
        print(f"Error querying Chroma: {e}")
        return None

# Renamed function and updated to handle generic status
def update_assessment_status(collection, doc_id, new_status, comments):
    """Updates the status and comments for a specific assessment."""
    if new_status not in ["Approved", "Rejected", "Pending"]: # Basic validation
        print(f"Error: Invalid status '{new_status}' provided.")
        return False
    try:
        # Chroma doesn't have a direct 'update metadata' for a single field easily.
        # We get the existing record, update metadata, and use 'update' (or upsert).
        existing_record = collection.get(ids=[doc_id], include=['metadatas', 'embeddings', 'documents'])

        if not existing_record or not existing_record.get('ids'):
            print(f"Error: Document with ID {doc_id} not found for update.")
            return False

        # Assuming only one record is returned for the ID
        current_metadata = existing_record['metadatas'][0]
        current_embedding = existing_record['embeddings'][0]
        current_document = existing_record['documents'][0]

        # Update the metadata
        current_metadata['status'] = new_status # Use the new status field
        current_metadata['comments'] = comments if comments else "" # Ensure comments is not None
        if 'approved' in current_metadata: # Remove old 'approved' field if it exists
            del current_metadata['approved']


        # Use upsert to update the record
        collection.upsert(
            ids=[doc_id],
            embeddings=[current_embedding],
            documents=[current_document],
            metadatas=[current_metadata]
        )
        print(f"Updated status to '{new_status}' for ID: {doc_id}")
        return True
    except Exception as e:
        print(f"Error updating assessment status in Chroma: {e}")
        return False

def get_all_assessments(collection):
    """Retrieves all assessments from the collection."""
    try:
        # Get all items. Be cautious with very large collections.
        # Consider pagination or filtering if performance becomes an issue.
        # 'ids' are returned by default and should not be in 'include'
        results = collection.get(include=['metadatas']) # Removed 'ids' from include
        assessments = []
        if results and results.get('ids'): # Check if 'ids' key exists in the result
            for i, doc_id in enumerate(results['ids']):
                 # Ensure metadatas list is long enough
                 if i < len(results.get('metadatas', [])):
                     metadata = results['metadatas'][i]
                 else:
                     metadata = {} # Handle case where metadata might be missing unexpectedly

                 # Add the ID to the metadata dict if it's not already there
                 if metadata is not None and 'id' not in metadata:
                     metadata['id'] = doc_id
                 assessments.append(metadata)
        # Sort by timestamp descending (newest first)
        assessments.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
        return assessments
    except Exception as e:
        print(f"Error retrieving all assessments from Chroma: {e}")
        return []
