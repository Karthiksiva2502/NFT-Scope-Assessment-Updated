# Functions for composing prompts and interacting with the OpenAI API
import openai
import json

# --- Constants ---
# Use a model version that supports JSON mode
GPT_MODEL = "gpt-4-turbo-preview" # Changed from "gpt-4"

# --- Prompt Composition ---
def compose_prompt(requirement_text, context, similar_requirements=None):
    """Composes the prompt for GPT-4 analysis."""

    prompt = f"""
Analyze the following software requirement to assess its associated risks, focusing on non-functional aspects.

**Requirement:**
```
{requirement_text}
```
"""

    # Dynamically build the context section
    if context: # Check if context dictionary is not empty
        prompt += "\n**Context provided by the user:**\n"
        for key, value in context.items():
            if value and str(value).strip() and str(value).lower() != 'n/a': # Ensure value is meaningful
                prompt += f"- {key}: {value}\n"
    else:
        prompt += "\n**Context provided by the user:**\n- N/A (No specific context provided for this item beyond project name/type if available)\n"

    if similar_requirements:
        prompt += "\n**Similar Past Requirements Found (for context):**\n"
        for i, req in enumerate(similar_requirements):
            past_meta = req.get('metadata', {})
            prompt += f"{i+1}. Requirement Text: {past_meta.get('requirement_text', 'N/A')}\n"
            prompt += f"   - Assessed Risk: {past_meta.get('risk', 'N/A')}\n"
            prompt += f"   - Reasoning: {past_meta.get('reasoning', 'N/A')}\n"
            prompt += f"   - Recommendations: {past_meta.get('recommendations', 'N/A')}\n"
            prompt += f"   - Approved: {past_meta.get('approved', 'N/A')}\n"
            prompt += f"   - Comments: {past_meta.get('comments', 'N/A')}\n\n"
        prompt += "Consider these past assessments when evaluating the current requirement. You may reuse or adapt the previous reasoning and recommendations if applicable, but tailor the assessment to the current requirement's specific text and context.\n"

    prompt += """
**Analysis Task:**

Based on the requirement and the provided context (and considering any similar past requirements if provided), perform the following:

1.  **Risk Classification:** Classify the overall non-functional risk associated with implementing this requirement as **High**, **Medium**, or **Low**.
2.  **Reasoning:** Provide a clear and concise explanation for the assigned risk level, referencing specific aspects of the requirement and context.
3.  **Recommended Testing:** List the key non-functional testing types recommended (e.g., Performance, Security, Usability, Accessibility, Reliability, Compatibility). Be specific where possible.
4.  **Impact of Not Testing:** Briefly explain the potential negative impact or consequences if the recommended testing (especially for High/Medium risk items) is skipped.

**Output Format:**

Please provide the response as a JSON object with the following keys:
- "risk": (string: "High", "Medium", or "Low")
- "reasoning": (string: Detailed explanation)
- "recommendations": (string: List of testing types and brief description)
- "impact": (string: Explanation of consequences if testing is skipped)

Example JSON structure:
{
  "risk": "Medium",
  "reasoning": "The requirement involves handling user data and has moderate performance expectations...",
  "recommendations": "- Performance Testing: Verify response times under expected load.\n- Security Testing: Check for vulnerabilities related to data handling.",
  "impact": "Skipping performance testing could lead to slow response times and user dissatisfaction. Ignoring security testing could result in data breaches."
}
"""
    return prompt

# --- GPT Interaction ---
def get_gpt_assessment(prompt, api_key):
    """Calls the OpenAI API to get the risk assessment."""
    if not api_key:
        # Using a simulated response if no API key is provided
        print("Warning: No OpenAI API Key provided. Returning simulated response.")
        return simulate_gpt_response()
        # raise ValueError("OpenAI API Key is required.") # Or raise error

    try:
        # Initialize client for this call - consider a more persistent client if making many calls
        client = openai.OpenAI(api_key=api_key)

        response = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[
                {"role": "system", "content": "You are an expert software risk analyst specializing in non-functional requirements."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}, # Request JSON output
            temperature=0.5, # Adjust temperature for creativity vs consistency
        )
        # Assuming the response format request is honored and content is valid JSON
        content = response.choices[0].message.content
        return parse_gpt_response(content)

    except openai.AuthenticationError:
         print("Error: OpenAI Authentication Failed. Check your API key.")
         # Return None or raise a specific exception for the UI to handle
         return {"error": "OpenAI Authentication Failed. Check your API key."}
    except openai.RateLimitError:
        print("Error: OpenAI Rate Limit Exceeded.")
        return {"error": "OpenAI Rate Limit Exceeded. Please try again later."}
    except Exception as e:
        print(f"Error calling OpenAI API: {e}")
        # Return None or a generic error structure
        return {"error": f"An error occurred while contacting OpenAI: {e}"}


# --- Response Parsing ---
def parse_gpt_response(response_content):
    """Parses the JSON response from GPT."""
    try:
        # The response content should already be a JSON string
        parsed_data = json.loads(response_content)

        # Basic validation of expected keys
        required_keys = ["risk", "reasoning", "recommendations", "impact"]
        if not all(key in parsed_data for key in required_keys):
            print("Warning: GPT response missing expected keys.")
            # Handle missing keys - maybe return partial data or an error structure
            parsed_data["error"] = "Response format incorrect - missing keys."
            return parsed_data # Return partial data with error flag

        # Validate risk level (optional but good practice)
        valid_risks = ["High", "Medium", "Low"]
        if parsed_data.get("risk") not in valid_risks:
             print(f"Warning: Invalid risk level '{parsed_data.get('risk')}' received.")
             # Decide how to handle: default to Medium? Add error flag?
             # parsed_data["original_risk"] = parsed_data["risk"] # Keep original
             # parsed_data["risk"] = "Medium" # Force a valid value
             parsed_data["error"] = f"Invalid risk level '{parsed_data.get('risk')}' received."


        return parsed_data
    except json.JSONDecodeError:
        print("Error: Failed to decode GPT response as JSON.")
        print("Raw response:", response_content)
        return {"error": "Failed to decode GPT response."}
    except Exception as e:
        print(f"Error parsing GPT response: {e}")
        return {"error": f"An error occurred while parsing the response: {e}"}

# --- Simulation for Development/Testing ---
def simulate_gpt_response():
    """Provides a realistic simulated GPT response for testing without API calls."""
    # Simulate different risk levels based on some logic or randomly
    import random
    risk_levels = ["High", "Medium", "Low"]
    risk = random.choice(risk_levels)

    reasoning_options = {
        "High": "Involves complex third-party integrations and handles highly sensitive financial data under strict performance SLAs. Potential for significant security vulnerabilities and performance bottlenecks.",
        "Medium": "Handles user PII and requires integration with an external authentication service. Moderate user volume expected. Needs careful security and performance validation.",
        "Low": "Internal tool enhancement, displaying non-sensitive data with relaxed performance needs. Primarily requires usability and basic reliability checks."
    }
    recommendations_options = {
        "High": "- **Security Testing:** Penetration testing, vulnerability scanning, code review focusing on data handling and API interactions.\n- **Performance Testing:** Load testing (peak volume), stress testing, soak testing.\n- **Reliability Testing:** Fault injection, recovery testing.\n- **Accessibility Testing:** WCAG AA compliance checks.",
        "Medium": "- **Security Testing:** Vulnerability scanning, secure coding checks for PII handling.\n- **Performance Testing:** Load testing (expected volume).\n- **Usability Testing:** User acceptance testing with target users.\n- **Integration Testing:** Verify third-party API contracts and error handling.",
        "Low": "- **Usability Testing:** Basic workflow checks.\n- **Compatibility Testing:** Verify on standard internal browsers/OS.\n- **Regression Testing:** Ensure no existing functionality is broken."
    }
    impact_options = {
        "High": "Failure to test could lead to major data breaches, system outages impacting revenue, significant reputational damage, and failure to meet regulatory compliance.",
        "Medium": "Skipping testing may result in data leaks, poor performance leading to user abandonment, and integration failures causing service disruptions.",
        "Low": "Neglecting testing might lead to minor usability issues or browser compatibility problems, causing internal user frustration but low business impact."
    }

    return {
        "risk": risk,
        "reasoning": reasoning_options[risk],
        "recommendations": recommendations_options[risk],
        "impact": impact_options[risk]
    }
