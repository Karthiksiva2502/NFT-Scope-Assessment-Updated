# NFT Requirement Risk Assessment Tool

This Streamlit web application helps assess the non-functional risks associated with software requirements, particularly for projects that might involve Non-Fungible Tokens (NFTs) or similar digital assets, though it can be used for general software requirements.

## Features

*   **Requirement Input:** Users can upload requirement documents (.txt, .docx) or enter requirement text manually.
*   **Contextual Analysis:** The application gathers contextual information about the project (e.g., project type, data sensitivity, user volume) to aid in risk assessment.
*   **AI-Powered Risk Assessment:** Uses OpenAI's GPT-4 API to:
    *   Classify the risk of a requirement as High, Medium, or Low.
    *   Provide reasoning for the classification.
    *   Recommend non-functional testing types.
    *   Explain the impact of not performing the recommended testing.
*   **Requirement Enhancement Assistant:** 
    *   Automatically evaluates if requirements have enough detail for proper analysis
    *   Provides an interactive chat interface to help users improve insufficient requirements
    *   Guides users with specific questions to gather necessary details
    *   Generates enhanced requirements based on the conversation
*   **Vector Database Integration:**
    *   Converts requirements into embeddings using OpenAI's `text-embedding-3-small` model.
    *   Stores these embeddings and associated assessment metadata (requirement text, risk, recommendations, project name, status, comments) in a local Chroma vector database.
    *   Searches the database for similar past requirements to provide context for new assessments, potentially improving consistency and reusing past knowledge.
*   **Architect Review Workflow:**
    *   Allows an architect or reviewer to add comments.
    *   Provides "Approve" and "Reject" buttons to update the assessment status in the database.
*   **Reporting:**
    *   Generates a PDF report for each assessment, including all details and review status.
*   **Previous Results:**
    *   A dedicated tab to view, filter, and sort past assessments.
    *   Full details of past assessments can be viewed in a popover.
    *   PDF reports for past assessments can be re-downloaded.

## Setup and Installation

1.  **Prerequisites:**
    *   Python 3.8 or higher.
    *   `pip` (Python package installer).

2.  **Clone the Repository (if applicable):**
    If this project is in a Git repository, clone it:
    ```bash
    git clone <repository_url>
    cd NFT-RiskAssessment
    ```
    If you just have the files, navigate to the project directory (`/Users/Sudi/Centrica/NFT-RiskAssessment`).

3.  **Create a Virtual Environment (Recommended):**
    It's good practice to use a virtual environment to manage project dependencies.
    ```bash
    python -m venv .venv
    ```
    Activate the virtual environment:
    *   On macOS/Linux:
        ```bash
        source .venv/bin/activate
        ```
    *   On Windows:
        ```bash
        .\.venv\Scripts\activate
        ```

4.  **Install Dependencies:**
    Install the required Python packages using the `requirements.txt` file:
    ```bash
    pip install -r requirements.txt
    ```

## Running the Application

1.  **Navigate to the Project Directory:**
    Ensure your terminal is in the root directory of the project (e.g., `/Users/Sudi/Centrica/NFT-RiskAssessment`).

2.  **Set OpenAI API Key:**
    The application requires an OpenAI API key to function. You will be prompted to enter this key in the application's sidebar. Ensure you have a valid key with access to the GPT-4 and embedding models.

3.  **Run the Streamlit App:**
    Execute the following command in your terminal:
    ```bash
    python -m streamlit run app.py
    ```
    Or, if `streamlit` is directly in your PATH:
    ```bash
    streamlit run app.py
    ```

4.  **Access the Application:**
    Once the server starts, it will typically display a local URL in your terminal (e.g., `http://localhost:8501` or `http://localhost:8502`). Open this URL in your web browser to use the application.

## Project Structure

*   `app.py`: The main Streamlit application script.
*   `chroma_logic.py`: Handles interactions with the Chroma vector database and embedding generation.
*   `file_parser.py`: Contains functions for parsing uploaded requirement documents.
*   `gpt_logic.py`: Manages prompt composition and communication with the OpenAI API.
*   `pdf_generator.py`: Responsible for creating PDF reports of assessments.
*   `requirements.txt`: Lists all Python dependencies for the project.
*   `./chroma_db/`: Directory where the local Chroma database is stored (will be created automatically).
*   `README.md`: This file.

## Notes

*   The Chroma database is stored locally in the `chroma_db` sub-directory. If you delete this directory, all past assessment data will be lost.
*   Ensure your OpenAI API key has sufficient quota and access to the specified models (`gpt-4-turbo-preview` and `text-embedding-3-small`).
