# Main Streamlit application file
import streamlit as st
import file_parser
import chroma_logic
import gpt_logic
import pdf_generator
import time
import pandas as pd
import openai # Import the openai library

# --- Initialize session state ---
# Initialize API key in session state first since check_mandatory_fields() depends on it
if 'api_key_input_global' not in st.session_state:
    st.session_state.api_key_input_global = ""

if 'assessment_result' not in st.session_state:
    st.session_state.assessment_result = None
if 'similar_requirements' not in st.session_state:
    st.session_state.similar_requirements = None
if 'current_requirement_text' not in st.session_state:
    st.session_state.current_requirement_text = ""
if 'current_context' not in st.session_state:
    st.session_state.current_context = {} # Will be populated by sidebar
if 'assessment_id' not in st.session_state:
    st.session_state.assessment_id = None
if 'all_fields_filled' not in st.session_state:
    st.session_state.all_fields_filled = False
if 'project_type_selection' not in st.session_state: # To store the project type
    st.session_state.project_type_selection = 'New Project' # Default
# Ensure the radio button's state key is initialized
if 'ctx_project_type_sidebar_global' not in st.session_state:
    st.session_state.ctx_project_type_sidebar_global = 'New Project'
# Initialize chat-related session states
if 'chat_active' not in st.session_state:
    st.session_state.chat_active = False
if 'chat_messages' not in st.session_state:
    st.session_state.chat_messages = []
if 'requirement_sufficient' not in st.session_state:
    st.session_state.requirement_sufficient = False
if 'enhanced_requirement' not in st.session_state:
    st.session_state.enhanced_requirement = ""
# Add session state for chat-specific feedback
if 'chat_sufficiency_feedback' not in st.session_state:
    st.session_state.chat_sufficiency_feedback = ""
if 'chat_is_currently_sufficient' not in st.session_state:
    st.session_state.chat_is_currently_sufficient = False
if 'batch_assessment_results' not in st.session_state:
    st.session_state.batch_assessment_results = [] # For storing results of batch processing
# Add session state for user-configurable search parameters
if 'user_similarity_threshold' not in st.session_state:
    st.session_state.user_similarity_threshold = chroma_logic.DEFAULT_SIMILARITY_THRESHOLD # Default from chroma_logic
if 'user_n_results' not in st.session_state:
    st.session_state.user_n_results = chroma_logic.DEFAULT_N_RESULTS # Default from chroma_logic

st.set_page_config(layout="wide", page_title="NFT Requirement Risk Assessor")
st.title("NFT Requirement Risk Assessment Tool")

# Define lists of widget keys for each project type for easier state management
new_project_widget_keys = [
    'ctx_np_target_audience_sidebar_global',
    'ctx_np_core_functionality_sidebar_global',
    'ctx_np_data_sensitivity_sidebar_global',
    'ctx_np_expected_user_volume_sidebar_global',
    'ctx_np_performance_needs_sidebar_global',
    'ctx_np_integration_points_sidebar_global',
    'ctx_np_regulatory_compliance_sidebar_global',
    'ctx_np_security_concerns_sidebar_global',
    'ctx_np_deployment_env_sidebar_global',
    'ctx_np_scalability_needs_sidebar_global'
]
enhancement_widget_keys = [
    'ctx_enh_affected_module_sidebar_global',
    'ctx_enh_current_limitations_sidebar_global',
    'ctx_enh_impact_on_existing_sidebar_global',
    'ctx_enh_data_migration_sidebar_global',
    'ctx_enh_performance_impact_sidebar_global',
    'ctx_enh_security_implications_sidebar_global',
    'ctx_enh_user_impact_sidebar_global',
    'ctx_enh_dependencies_sidebar_global',
    'ctx_enh_rollback_plan_sidebar_global',
    'ctx_enh_testing_scope_sidebar_global'
]

# Function to check if all mandatory fields are filled
def check_mandatory_fields(current_project_type): # Added current_project_type argument
    # Check if API key is provided
    if not st.session_state.api_key_input_global:
        return False
    
    # Common mandatory fields
    common_required = [
        'ctx_project_name_sidebar_global',
        'ctx_project_type_sidebar_global' # Project type itself is always required
    ]
    for field in common_required:
        if field not in st.session_state or not st.session_state[field]:
            return False

    # Dynamically set required fields based on project type
    project_type_specific_required = []
    if current_project_type == 'New Project': # Use argument here
        project_type_specific_required = new_project_widget_keys
    elif current_project_type == 'Enhancement': # Use argument here
        project_type_specific_required = enhancement_widget_keys

    for field in project_type_specific_required:
        if field not in st.session_state or not st.session_state[field]:
            return False
            
    return True

# Function to handle state changes when project type is modified
def project_type_changed_callback():
    selected_type = st.session_state.ctx_project_type_sidebar_global
    st.session_state.current_context['project_type'] = selected_type
    
    # Clear states of the non-selected type's widgets and their context entries
    if selected_type == 'New Project':
        for wk in enhancement_widget_keys:
            if wk in st.session_state:
                st.session_state.pop(wk, None) # Remove widget state
        enh_ctx_keys = [k for k in st.session_state.current_context if k.startswith('enh_')]
        for k_ctx in enh_ctx_keys:
            st.session_state.current_context.pop(k_ctx, None)
    elif selected_type == 'Enhancement':
        for wk in new_project_widget_keys:
            if wk in st.session_state:
                st.session_state.pop(wk, None) # Remove widget state
        np_ctx_keys = [k for k in st.session_state.current_context if k.startswith('np_')]
        for k_ctx in np_ctx_keys:
            st.session_state.current_context.pop(k_ctx, None)
    
    # Reset assessment details as context has changed
    st.session_state.assessment_result = None
    st.session_state.assessment_id = None
    st.session_state.similar_requirements = None
    # This will be recalculated based on new state
    st.session_state.all_fields_filled = False
    
    # Don't call st.rerun() here as it's within a callback
    # Setting a flag instead to avoid the warning
    st.session_state.needs_rerun = True

# --- Sidebar (Contextual Info always visible, API key always visible) ---
st.sidebar.header("Configuration")
# api_key variable is local to this scope, session state holds the persistent value
st.sidebar.text_input("Enter OpenAI API Key: *", type="password", key="api_key_input_global", help="Your OpenAI API key is required for analysis.")
st.sidebar.header("Contextual Information (for New Assessment)")
st.sidebar.markdown("##### All fields are mandatory *")
st.session_state.current_context['project_name'] = st.sidebar.text_input(
    "Project Name: *", key='ctx_project_name_sidebar_global'
)

# Define project type radio button and assign its on_change callback
st.sidebar.radio(
    "Is this a new project or an enhancement? *",
    ('New Project', 'Enhancement'),
    key='ctx_project_type_sidebar_global', # This session state key is updated by the radio
    on_change=project_type_changed_callback
)

# Determine active project type from session state for rendering
active_project_type = st.session_state.ctx_project_type_sidebar_global
# Ensure current_context reflects this, though callback also does this.
st.session_state.current_context['project_type'] = active_project_type

st.sidebar.info(f"Showing questions for: **{active_project_type}**")

# Conditional questions based on project type
if active_project_type == 'New Project':
    st.sidebar.markdown("---")
    st.sidebar.markdown("##### New Project Details *")
    # The callback should have cleared enhancement widget states.
    # Now, render New Project widgets. Streamlit will initialize their state if not present.
    st.session_state.current_context['np_target_audience'] = st.sidebar.text_input(
        "Target Audience: *", key='ctx_np_target_audience_sidebar_global'
    )
    st.session_state.current_context['np_core_functionality'] = st.sidebar.text_area(
        "Core Functionality: *", height=100, key='ctx_np_core_functionality_sidebar_global'
    )
    st.session_state.current_context['np_data_sensitivity'] = st.sidebar.selectbox(
        "Data Sensitivity Level: *", ('Low', 'Medium', 'High (PII, Financial)'), key='ctx_np_data_sensitivity_sidebar_global'
    )
    st.session_state.current_context['np_expected_user_volume'] = st.sidebar.selectbox(
        "Expected User Volume: *", ('Low', 'Medium', 'High', 'Very High'), key='ctx_np_expected_user_volume_sidebar_global'
    )
    st.session_state.current_context['np_performance_needs'] = st.sidebar.selectbox(
        "Critical Performance Needs: *", ('Standard', 'High-throughput', 'Low-latency', 'Real-time'), key='ctx_np_performance_needs_sidebar_global'
    )
    st.session_state.current_context['np_integration_points'] = st.sidebar.text_area(
        "Key Integration Points (e.g., APIs, DBs): *", height=100, key='ctx_np_integration_points_sidebar_global'
    )
    st.session_state.current_context['np_regulatory_compliance'] = st.sidebar.text_input(
        "Regulatory/Compliance Needs (e.g., GDPR, HIPAA): *", key='ctx_np_regulatory_compliance_sidebar_global'
    )
    st.session_state.current_context['np_security_concerns'] = st.sidebar.text_area(
        "Major Security Concerns: *", height=100, key='ctx_np_security_concerns_sidebar_global'
    )
    st.session_state.current_context['np_deployment_env'] = st.sidebar.selectbox(
        "Deployment Environment: *", ('Cloud', 'On-premise', 'Hybrid'), key='ctx_np_deployment_env_sidebar_global'
    )
    st.session_state.current_context['np_scalability_needs'] = st.sidebar.selectbox(
        "Scalability Requirements: *", ('Low', 'Medium', 'High (auto-scaling)'), key='ctx_np_scalability_needs_sidebar_global'
    )
    # No need to clear enhancement_keys from current_context again here, done above
elif active_project_type == 'Enhancement':
    st.sidebar.markdown("---")
    st.sidebar.markdown("##### Enhancement Details *")
    # The callback should have cleared new project widget states.
    # Render Enhancement widgets.
    st.session_state.current_context['enh_affected_module'] = st.sidebar.text_input(
        "Affected Module/System: *", key='ctx_enh_affected_module_sidebar_global'
    )
    st.session_state.current_context['enh_current_limitations'] = st.sidebar.text_area(
        "Current Limitations Being Addressed: *", height=100, key='ctx_enh_current_limitations_sidebar_global'
    )
    st.session_state.current_context['enh_impact_on_existing'] = st.sidebar.selectbox(
        "Impact on Existing Functionality: *", ('None', 'Minor', 'Significant'), key='ctx_enh_impact_on_existing_sidebar_global'
    )
    st.session_state.current_context['enh_data_migration'] = st.sidebar.radio(
        "Data Migration Required? *", ('No', 'Yes'), key='ctx_enh_data_migration_sidebar_global'
    )
    st.session_state.current_context['enh_performance_impact'] = st.sidebar.selectbox(
        "Expected Performance Impact: *", ('None', 'Improvement', 'Potential Degradation'), key='ctx_enh_performance_impact_sidebar_global'
    )
    st.session_state.current_context['enh_security_implications'] = st.sidebar.text_area(
        "Security Implications of Change: *", height=100, key='ctx_enh_security_implications_sidebar_global'
    )
    st.session_state.current_context['enh_user_impact'] = st.sidebar.selectbox(
        "Impact on Users: *", ('Transparent', 'Minor UI Change', 'Major Workflow Change'), key='ctx_enh_user_impact_sidebar_global'
    )
    st.session_state.current_context['enh_dependencies'] = st.sidebar.text_area(
        "Dependencies on Other Systems/Modules: *", height=100, key='ctx_enh_dependencies_sidebar_global'
    )
    st.session_state.current_context['enh_rollback_plan'] = st.sidebar.radio(
        "Rollback Plan Exists? *", ('Yes', 'No', 'Partial'), key='ctx_enh_rollback_plan_sidebar_global'
    )
    st.session_state.current_context['enh_testing_scope'] = st.sidebar.text_area(
        "Specific Testing Scope for Enhancement: *", height=100, key='ctx_enh_testing_scope_sidebar_global'
    )
    # No need to clear new_project_keys from current_context again here, done above

# Check if all fields are filled after any change
# Pass the active_project_type to the check function
st.session_state.all_fields_filled = check_mandatory_fields(active_project_type)

# Display a message about mandatory fields if not all filled
if not st.session_state.all_fields_filled:
    st.sidebar.warning("⚠️ All fields marked with * are mandatory. Please fill them all to proceed.")

st.sidebar.markdown("---")
st.sidebar.header("Search Configuration")
st.session_state.user_similarity_threshold = st.sidebar.slider(
    "Similarity Distance Cutoff (lower is stricter):",
    min_value=0.1, max_value=1.5, # Cosine distance can be > 1 if embeddings are not perfectly normalized or due to numerical precision
    value=st.session_state.user_similarity_threshold,
    step=0.05,
    help="Controls how similar a past requirement must be to be shown. A lower value means only very similar results are shown."
)
st.session_state.user_n_results = st.sidebar.number_input(
    "Max Similar Results to Fetch:",
    min_value=1, max_value=20,
    value=st.session_state.user_n_results,
    step=1,
    help="The maximum number of similar past assessments to retrieve for context."
)

# Function to evaluate requirement quality
def evaluate_requirement_quality(requirement_text, api_key):
    """Uses GPT to evaluate if a requirement has sufficient information for analysis"""
    if not requirement_text:
        return False, "Requirement is empty"
        
    # Accept any text as sufficient to enable the Analyze button with minimal input
    if len(requirement_text.strip()) < 10:
        # For very short texts, still mark as sufficient but give feedback
        return True, "Very minimal requirement provided"
    
    try:
        client = openai.OpenAI(api_key=api_key)
        
        prompt = f"""
        Analyze the following software requirement text and determine if it contains sufficient information for a non-functional risk assessment:
        
        ```
        {requirement_text}
        ```
        
        Please answer with just 'SUFFICIENT' if the requirement is detailed enough for analysis, or 'INSUFFICIENT' if more information is needed, followed by a brief explanation of what's missing.
        """
        
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # Use a smaller model for this quick evaluation
            messages=[
                {"role": "system", "content": "You are an expert in software requirements analysis. Evaluate if requirements contain enough information for non-functional risk assessment."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=100
        )
        
        result = response.choices[0].message.content.strip()
        if result.startswith('SUFFICIENT'):
            return True, result.replace('SUFFICIENT', '').strip()
        else:
            return True, result.replace('INSUFFICIENT', '').strip()  # Still return True to enable the button
    except Exception as e:
        print(f"Error evaluating requirement: {e}")
        return True, "Proceeding with minimal requirement"  # Return True to enable the button despite error

# Function to handle chat interaction
def get_ai_response(message, api_key, requirement_text):
    """Get AI Assistant response for the chat"""
    try:
        client = openai.OpenAI(api_key=api_key)
        
        # Prepare conversation history
        messages = [
            {"role": "system", "content": "You are an AI assistant helping gather detailed requirements for non-functional risk assessment. Ask specific clarifying questions, one at a time. Aim to enhance the requirement with details about functionality, constraints, user expectations, and technical context. Keep responses concise and focused on requirements gathering."},
        ]
        
        # Add the original requirement for context
        messages.append({"role": "system", "content": f"Original requirement provided by user: {requirement_text}"})
        
        # Add conversation history
        for msg in st.session_state.chat_messages:
            messages.append(msg)
        
        # Add current message
        messages.append({"role": "user", "content": message})
        
        # Get response
        response = client.chat.completions.create(
            model="gpt-4",  # Using GPT-4 for better quality conversation
            messages=messages,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    except Exception as e:
        print(f"Error in chat: {e}")
        return "I'm having trouble processing your request. Please try again."

# Function to enhance requirement based on chat
def generate_enhanced_requirement(api_key):
    """Generate an enhanced requirement based on the chat conversation"""
    try:
        client = openai.OpenAI(api_key=api_key)
        
        # Extract the original requirement (first system message)
        original_req = None
        for msg in st.session_state.chat_messages:
            if "Original requirement provided by user:" in msg.get("content", ""):
                original_req = msg["content"].replace("Original requirement provided by user:", "").strip()
                break
        if not original_req:
            original_req = st.session_state.current_requirement_text
        
        # Prepare messages for enhanced requirement generation
        messages = [
            {"role": "system", "content": "You are an AI assistant that helps create well-formed software requirements from discussions. Synthesize the conversation into a clear, detailed requirement specification that includes functional and non-functional aspects."},
            {"role": "user", "content": f"Based on this original requirement: '{original_req}' and the following conversation, create an enhanced, well-structured requirement:"}
        ]
        
        # Add the conversation
        for msg in st.session_state.chat_messages:
            if msg["role"] != "system":  # Skip system messages
                messages.append(msg)
        
        # Get the enhanced requirement
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            temperature=0.5
        )
        
        return response.choices[0].message.content
    except Exception as e:
        print(f"Error generating enhanced requirement: {e}")
        return st.session_state.current_requirement_text

# --- Main App Area with Tabs ---
tab1, tab2 = st.tabs(["New Assessment", "Previous Results"])

with tab1:
    st.header("Submit New Requirement")
    
    # Display a notice at the top if fields aren't filled
    if not st.session_state.all_fields_filled:
        st.warning("⚠️ Please fill all mandatory fields in the sidebar before proceeding.")
        
    input_method = st.radio("Choose input method:", ("Upload File", "Enter Text Manually", "Bulk Upload (CSV)"), horizontal=True, key="input_method_choice_tab1")
    uploaded_file = None
    manual_text = ""

    if input_method == "Upload File":
        uploaded_file = st.file_uploader("Upload Requirement Document (.txt or .docx)", type=['txt', 'docx'], key='file_uploader_tab1_single')
        if uploaded_file: 
            st.session_state.manual_text_tab1 = ""
            st.session_state.batch_assessment_results = [] # Clear batch results
            # Reset chat state when file changes
            st.session_state.chat_active = False
            st.session_state.chat_messages = []
            st.session_state.requirement_sufficient = False
    elif input_method == "Enter Text Manually":
        # Show the requirement text area
        manual_text = st.text_area("Enter Requirement Text:", height=200, key='manual_text_tab1')
        st.session_state.batch_assessment_results = [] # Clear batch results
        
        # Process requirement when it changes
        if 'last_manual_text' not in st.session_state or st.session_state.last_manual_text != manual_text:
            st.session_state.last_manual_text = manual_text
            
            # Reset chat state when text changes significantly
            if manual_text:
                # Evaluate requirement quality when text changes and API key is available
                if st.session_state.api_key_input_global and len(manual_text.strip()) > 10:
                    is_sufficient, reason = evaluate_requirement_quality(manual_text, st.session_state.api_key_input_global)
                    st.session_state.requirement_sufficient = is_sufficient
                    
                    if not is_sufficient and not st.session_state.chat_active:
                        # Store original requirement
                        st.session_state.current_requirement_text = manual_text
                        # Initialize chat
                        st.session_state.chat_active = True
                        st.session_state.chat_messages = [
                            {"role": "system", "content": f"Original requirement provided by user: {manual_text}"}
                        ]
                        # Set initial chat feedback
                        st.session_state.chat_is_currently_sufficient = False
                        st.session_state.chat_sufficiency_feedback = f"⚠️ Initial assessment: {reason}"
                else:
                    st.session_state.requirement_sufficient = False
                    st.session_state.chat_sufficiency_feedback = "" # Clear if no API key or too short
                    st.session_state.chat_is_currently_sufficient = False
            else:
                st.session_state.chat_active = False
                st.session_state.chat_messages = []
                st.session_state.requirement_sufficient = False
                st.session_state.chat_sufficiency_feedback = ""
                st.session_state.chat_is_currently_sufficient = False
    
    elif input_method == "Bulk Upload (CSV)":
        uploaded_file = st.file_uploader("Upload CSV file with a 'requirement_text' column", type=['csv'], key='file_uploader_tab1_bulk')
        st.info("Ensure your CSV has a column named 'requirement_text' (or similar like 'Requirement Text', 'requirement'). Context from the sidebar will be applied to all requirements in the file.")
        if uploaded_file:
            st.session_state.manual_text_tab1 = "" # Clear manual text
            st.session_state.assessment_result = None # Clear single assessment result
            st.session_state.assessment_id = None


    # --- Replace the show_chat_modal function with a container-based approach ---
    def show_chat_interface():
        """Displays a chat interface using Streamlit containers instead of modal"""
        chat_container = st.container()
        with chat_container:
            st.markdown("## Requirement Enhancement Assistant")
            st.info("I'll help you enhance your requirement with more details to improve analysis quality.")
            
            # Display sufficiency feedback
            if st.session_state.chat_sufficiency_feedback:
                if st.session_state.chat_is_currently_sufficient:
                    st.success(st.session_state.chat_sufficiency_feedback)
                else:
                    st.warning(st.session_state.chat_sufficiency_feedback)
            
            # Custom CSS for chat bubbles
            st.markdown(
                """
                <style>
                .chat-bubble-user {background:#e6f7ff;padding:10px;border-radius:10px 10px 0 10px;margin-bottom:8px;}
                .chat-bubble-ai {background:#f0f0f0;padding:10px;border-radius:10px 10px 10px 0;margin-bottom:8px;}
                .chat-scroll {max-height:300px;overflow-y:auto;}
                </style>
                """, unsafe_allow_html=True
            )
            
            # Message display area
            message_area = st.container()
            with message_area:
                st.markdown('<div class="chat-scroll">', unsafe_allow_html=True)
                for i, message in enumerate(st.session_state.chat_messages):
                    if message["role"] != "system":
                        if message["role"] == "user":
                            st.markdown(f'<div class="chat-bubble-user"><b>You:</b> {message["content"]}</div>', unsafe_allow_html=True)
                        else:
                            st.markdown(f'<div class="chat-bubble-ai"><b>AI:</b> {message["content"]}</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
            
            # Input and action buttons
            chat_input = st.text_input("Your response:", key="chat_input_container")
            col1, col2, col3 = st.columns([3, 1, 1])
            
            # Define callback handlers for the buttons to avoid st.rerun() in callbacks
            def send_message():
                if st.session_state.chat_input_container:
                    st.session_state.chat_messages.append({"role": "user", "content": st.session_state.chat_input_container})
                    with st.spinner("AI is thinking..."):
                        ai_response = get_ai_response(
                            st.session_state.chat_input_container, 
                            st.session_state.api_key_input_global, 
                            st.session_state.current_requirement_text
                        )
                        st.session_state.chat_messages.append({"role": "assistant", "content": ai_response})
                    
                    # Re-evaluate and update feedback
                    current_conversation_text_for_feedback = generate_enhanced_requirement(st.session_state.api_key_input_global)
                    is_sufficient_now, feedback_reason = evaluate_requirement_quality(
                        current_conversation_text_for_feedback, 
                        st.session_state.api_key_input_global
                    )
                    st.session_state.chat_is_currently_sufficient = is_sufficient_now
                    if is_sufficient_now:
                        st.session_state.chat_sufficiency_feedback = "✅ Good progress! The requirement seems more detailed. Consider using 'Generate Enhanced Requirement' if you think it's complete."
                    else:
                        st.session_state.chat_sufficiency_feedback = f"⚠️ Still needs more detail: {feedback_reason}"
                    
                    # Clear input field after sending
                    st.session_state.chat_input_container = ""
                    # Set flag for UI update
                    st.session_state.needs_chat_refresh = True
            
            def generate_enhanced():
                with st.spinner("Generating enhanced requirement..."):
                    enhanced_req = generate_enhanced_requirement(st.session_state.api_key_input_global)
                    st.session_state.enhanced_requirement = enhanced_req
                    st.session_state.manual_text_tab1 = enhanced_req
                    st.session_state.current_requirement_text = enhanced_req
                    is_sufficient, reason = evaluate_requirement_quality(enhanced_req, st.session_state.api_key_input_global)
                    st.session_state.requirement_sufficient = is_sufficient
                    if is_sufficient:
                        st.session_state.chat_active = False
                        st.session_state.success_message = "Requirement is now sufficient for analysis!"
                        # Reset chat-specific feedback
                        st.session_state.chat_sufficiency_feedback = ""
                        st.session_state.chat_is_currently_sufficient = False
                    else:
                        # Update feedback if still insufficient after explicit generation attempt
                        st.session_state.chat_is_currently_sufficient = False
                        st.session_state.chat_sufficiency_feedback = f"⚠️ After generation: Still needs more detail. {reason}"
                    # Set flag for UI update
                    st.session_state.needs_chat_refresh = True
            
            def close_chat():
                st.session_state.chat_active = False
                # Reset chat-specific feedback
                st.session_state.chat_sufficiency_feedback = ""
                st.session_state.chat_is_currently_sufficient = False
                # Set flag for UI update
                st.session_state.needs_chat_refresh = True
            
            with col1:
                if st.button("Send", key="send_chat_container", on_click=send_message):
                    pass  # Processing happens in the callback
                    
            with col2:
                if st.button("Generate Enhanced Requirement", key="enhance_req_container", on_click=generate_enhanced):
                    pass  # Processing happens in the callback
                    
            with col3:
                if st.button("Close Chat", key="close_chat_container", on_click=close_chat):
                    pass  # Processing happens in the callback

    # --- Show chat interface if chat is active ---
    if st.session_state.chat_active and input_method == "Enter Text Manually" and st.session_state.api_key_input_global:
        show_chat_interface()

    # Determine if analysis button should be enabled
    button_disabled = not st.session_state.all_fields_filled
    if input_method == "Enter Text Manually":
        # For manual text, we also need sufficient requirements
        if not st.session_state.requirement_sufficient:
            button_disabled = True
    elif input_method == "Bulk Upload (CSV)":
        if not uploaded_file: # Disable if no file is uploaded for bulk
            button_disabled = True
    elif input_method == "Upload File":
        if not uploaded_file: # Disable if no file is uploaded for single
            button_disabled = True


    # Disable the analyze button if mandatory fields aren't filled or requirement is insufficient
    analyze_button = st.button("Analyze Requirement(s)", key="analyze_button_tab1", disabled=button_disabled)

    if analyze_button:
        st.session_state.batch_assessment_results = [] # Clear previous batch results
        st.session_state.assessment_result = None # Clear single result
        st.session_state.assessment_id = None

        if input_method == "Bulk Upload (CSV)" and uploaded_file is not None:
            requirements_list, error_msg = file_parser.parse_file(uploaded_file)
            if error_msg:
                st.error(error_msg)
            elif not requirements_list:
                st.warning("No requirements found in the CSV file or the 'requirement_text' column is empty.")
            else:
                st.info(f"Found {len(requirements_list)} requirements in the CSV. Starting batch analysis...")
                
                # Prepare context once for the whole batch
                current_api_key = st.session_state.api_key_input_global
                context_for_prompt = {}
                project_name_val = st.session_state.current_context.get('project_name')
                if project_name_val: context_for_prompt["Project Name"] = project_name_val
                project_type_val = st.session_state.current_context.get('project_type')
                if project_type_val: context_for_prompt["Project Type"] = project_type_val
                
                new_project_mappings = {
                    'np_target_audience': "Target Audience", 'np_core_functionality': "Core Functionality",
                    'np_data_sensitivity': "Data Sensitivity Level", 'np_expected_user_volume': "Expected User Volume",
                    'np_performance_needs': "Critical Performance Needs", 'np_integration_points': "Key Integration Points",
                    'np_regulatory_compliance': "Regulatory/Compliance Needs", 'np_security_concerns': "Major Security Concerns",
                    'np_deployment_env': "Deployment Environment", 'np_scalability_needs': "Scalability Requirements"
                }
                enhancement_mappings = {
                    'enh_affected_module': "Affected Module/System", 'enh_current_limitations': "Current Limitations Being Addressed",
                    'enh_impact_on_existing': "Impact on Existing Functionality", 'enh_data_migration': "Data Migration Required?",
                    'enh_performance_impact': "Expected Performance Impact", 'enh_security_implications': "Security Implications of Change",
                    'enh_user_impact': "Impact on Users", 'enh_dependencies': "Dependencies on Other Systems/Modules",
                    'enh_rollback_plan': "Rollback Plan Exists?", 'enh_testing_scope': "Specific Testing Scope for Enhancement"
                }
                active_mappings = new_project_mappings if project_type_val == 'New Project' else enhancement_mappings
                for key_prefix, desc_label in active_mappings.items():
                    session_key = f"ctx_{key_prefix}_sidebar_global"
                    value = st.session_state.get(session_key)
                    if value: context_for_prompt[desc_label] = value

                batch_progress = st.progress(0)
                temp_status = st.empty()
                processed_count = 0

                for i, req_text in enumerate(requirements_list):
                    temp_status.info(f"Processing requirement {i+1}/{len(requirements_list)}: '{req_text[:50]}...'")
                    if not req_text or len(req_text.strip()) < 5: # Basic validation for each requirement
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": "Requirement text too short or empty.", 
                            "recommendations": "N/A", "impact": "N/A", "status": "Error", 
                            "comments": "Skipped due to insufficient text.", "timestamp": int(time.time())
                        })
                        processed_count +=1
                        batch_progress.progress(processed_count / len(requirements_list))
                        continue
                    try:
                        collection = chroma_logic.get_or_create_collection(current_api_key)
                        embedding = chroma_logic.generate_embedding(req_text, current_api_key)
                        # For batch, we might not want to use similar_requirements for each, or make it optional
                        # For simplicity, let's omit similar_requirements lookup in batch for now, or make it a toggle later
                        # similar_reqs = chroma_logic.find_similar_requirements(collection, embedding) 
                        prompt = gpt_logic.compose_prompt(req_text, context_for_prompt, None) # Passing None for similar_requirements
                        gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)

                        if gpt_response and "error" not in gpt_response:
                            doc_id = chroma_logic.add_assessment(
                                collection, req_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                project_name_val or "N/A"
                            )
                            st.session_state.batch_assessment_results.append({
                                "id": doc_id, "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                **gpt_response, "status": "Pending", "comments": "", "timestamp": int(time.time())
                            })
                        else:
                            error_detail = gpt_response.get('error', 'Unknown GPT error') if gpt_response else "No GPT response"
                            st.session_state.batch_assessment_results.append({
                                "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                                "risk": "Error", "reasoning": error_detail, "recommendations": "N/A", 
                                "impact": "N/A", "status": "Error", "comments": "Failed during GPT assessment.", "timestamp": int(time.time())
                            })
                    except Exception as e:
                        st.session_state.batch_assessment_results.append({
                            "id": "N/A", "requirement_text": req_text, "project_name": project_name_val or "N/A",
                            "risk": "Error", "reasoning": str(e), "recommendations": "N/A", 
                            "impact": "N/A", "status": "Error", "comments": "Failed during processing.", "timestamp": int(time.time())
                        })
                    processed_count += 1
                    batch_progress.progress(processed_count / len(requirements_list))
                
                temp_status.success(f"Batch analysis complete for {len(requirements_list)} requirements.")
                batch_progress.empty()


        elif input_method == "Upload File" and uploaded_file is not None:
            try:
                requirement_text, error_msg = file_parser.parse_file(uploaded_file)
                if error_msg:
                    st.error(error_msg)
                    requirement_text = None
                if requirement_text is None and not error_msg: st.error("Unsupported file type or empty file.")
            except Exception as e: st.error(f"Error reading file: {e}"); requirement_text = None
            st.session_state.current_requirement_text = requirement_text
            # --- Standard single requirement processing logic ---
            if requirement_text:
                 # This part is for single file/manual text, ensure it's not mixed with batch logic
                with st.spinner("Analyzing..."):
                    try:
                        current_api_key = st.session_state.api_key_input_global
                        # ... (rest of single analysis logic as before) ...
                        collection = chroma_logic.get_or_create_collection(current_api_key)
                        embedding = chroma_logic.generate_embedding(requirement_text, current_api_key)
                        st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                            collection,
                            embedding,
                            n_results=st.session_state.user_n_results,
                            custom_threshold=st.session_state.user_similarity_threshold
                        )
                        
                        context_for_prompt = {}
                        project_name_val = st.session_state.current_context.get('project_name')
                        if project_name_val: context_for_prompt["Project Name"] = project_name_val
                        project_type_val = st.session_state.current_context.get('project_type')
                        if project_type_val: context_for_prompt["Project Type"] = project_type_val
                        new_project_mappings = {
                            'np_target_audience': "Target Audience", 'np_core_functionality': "Core Functionality",
                            'np_data_sensitivity': "Data Sensitivity Level", 'np_expected_user_volume': "Expected User Volume",
                            'np_performance_needs': "Critical Performance Needs", 'np_integration_points': "Key Integration Points",
                            'np_regulatory_compliance': "Regulatory/Compliance Needs", 'np_security_concerns': "Major Security Concerns",
                            'np_deployment_env': "Deployment Environment", 'np_scalability_needs': "Scalability Requirements"
                        }
                        enhancement_mappings = {
                            'enh_affected_module': "Affected Module/System", 'enh_current_limitations': "Current Limitations Being Addressed",
                            'enh_impact_on_existing': "Impact on Existing Functionality", 'enh_data_migration': "Data Migration Required?",
                            'enh_performance_impact': "Expected Performance Impact", 'enh_security_implications': "Security Implications of Change",
                            'enh_user_impact': "Impact on Users", 'enh_dependencies': "Dependencies on Other Systems/Modules",
                            'enh_rollback_plan': "Rollback Plan Exists?", 'enh_testing_scope': "Specific Testing Scope for Enhancement"
                        }
                        active_mappings = new_project_mappings if project_type_val == 'New Project' else enhancement_mappings
                        for key_prefix, desc_label in active_mappings.items():
                            session_key = f"ctx_{key_prefix}_sidebar_global"
                            value = st.session_state.get(session_key)
                            if value: context_for_prompt[desc_label] = value
                        
                        prompt = gpt_logic.compose_prompt(requirement_text, context_for_prompt, st.session_state.similar_requirements)
                        gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)

                        if gpt_response and "error" in gpt_response:
                            st.error(f"Analysis failed: {gpt_response['error']}")
                            st.session_state.assessment_result = None; st.session_state.assessment_id = None
                        elif gpt_response:
                            st.session_state.assessment_result = gpt_response
                            doc_id = chroma_logic.add_assessment(
                                collection, requirement_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                st.session_state.current_context.get('project_name', 'N/A')
                            )
                            st.session_state.assessment_id = doc_id
                            if doc_id: st.success("Analysis complete!")
                            else: st.error("Failed to save to database.")
                        else:
                            st.error("Analysis failed. No response."); st.session_state.assessment_result = None; st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}"); st.session_state.assessment_result = None; st.session_state.assessment_id = None
            # --- End of standard single requirement processing logic ---

        elif input_method == "Enter Text Manually":
            requirement_text = st.session_state.manual_text_tab1
            st.session_state.current_requirement_text = requirement_text
            # --- Check requirement sufficiency before proceeding (for manual input) ---
            is_sufficient, reason = evaluate_requirement_quality(requirement_text, st.session_state.api_key_input_global)
            if not is_sufficient:
                st.session_state.requirement_sufficient = False
                st.session_state.chat_active = True
                if not st.session_state.chat_messages: # Should be populated by text_area on_change
                    st.session_state.chat_messages = [
                        {"role": "system", "content": f"Original requirement provided by user: {requirement_text}"}
                    ]
                # Update chat feedback for when modal opens due to "Analyze" click
                st.session_state.chat_is_currently_sufficient = False
                st.session_state.chat_sufficiency_feedback = f"⚠️ Requirement needs more detail: {reason}"
                st.warning("Requirement details are insufficient. The Enhancement Assistant will open to help you add more details.")
                st.session_state.needs_chat_refresh = True
                # Stop further processing until requirement is sufficient
            else:
                st.session_state.requirement_sufficient = True

            if not requirement_text: 
                st.warning("Please provide requirement text.")
            elif not st.session_state.requirement_sufficient: # If manual text is still not sufficient after button click
                 st.warning("Requirement details are insufficient. The Enhancement Assistant will help you add more details.")
                 # Dialog should appear from chat_active state
                 st.session_state.chat_active = True
                 # Set initial chat messages if they don't exist
                 if not st.session_state.chat_messages:
                     st.session_state.chat_messages = [
                         {"role": "system", "content": f"Original requirement provided by user: {requirement_text}"}
                     ]
                 # Update chat feedback
                 st.session_state.chat_is_currently_sufficient = False
                 st.session_state.chat_sufficiency_feedback = f"⚠️ Requirement needs more detail: {reason}"
                 st.session_state.needs_chat_refresh = True
                 # Stop further processing until requirement is sufficient
            else: # analyze_button is only enabled if all_fields_filled is True and requirement_sufficient is True
                with st.spinner("Analyzing..."):
                    try:
                        # Ensure api_key is retrieved from session_state for use
                        current_api_key = st.session_state.api_key_input_global # Consistent usage

                        # Get or create collection
                        try:
                            collection = chroma_logic.get_or_create_collection(current_api_key)
                        except openai.AuthenticationError as ae:
                            st.error(f"OpenAI Authentication Error: {str(ae)}")
                            st.info("Please ensure your API key is correct, valid, and has available quota in the sidebar.")
                            st.stop()
                        except ConnectionError as ce:
                            st.error(f"Network Connection Error: {str(ce)}")
                            st.info("Could not connect to OpenAI to prepare data store. Please check your internet connection and firewall settings.")
                            st.stop()
                        except Exception as e: # Catch other errors during collection creation
                            st.error(f"Error preparing data store: {str(e)}")
                            st.stop()
                        
                        # Add better error handling for embedding generation
                        try:
                            embedding = chroma_logic.generate_embedding(requirement_text, current_api_key)
                        except openai.AuthenticationError as ae: # Catch AuthenticationError specifically
                            st.error(f"OpenAI Authentication Error: {str(ae)}")
                            st.info("Please ensure your API key is correct, valid, and has available quota in the sidebar.")
                            st.stop()
                        except ConnectionError as ce:
                            st.error(f"Network Connection Error: {str(ce)}")
                            st.info("Please check your internet connection and firewall settings. If the problem persists, OpenAI servers may be experiencing issues.")
                            st.stop()
                        except Exception as ee: # General exception for embedding
                            st.error(f"Error generating embedding: {str(ee)}")
                            st.stop()
                            
                        if embedding is None: # Should ideally not be reached if exceptions are raised
                            st.error("Failed to generate embedding (unexpected)."); st.stop()
                        
                        st.session_state.similar_requirements = chroma_logic.find_similar_requirements(
                            collection,
                            embedding,
                            n_results=st.session_state.user_n_results,
                            custom_threshold=st.session_state.user_similarity_threshold
                        )
                        
                        # Prepare context for prompt, ensuring only relevant fields are passed
                        context_for_prompt = {}
                        
                        # Add project name and type first
                        project_name_val = st.session_state.current_context.get('project_name')
                        if project_name_val:
                            context_for_prompt["Project Name"] = project_name_val
                        
                        project_type_val = st.session_state.current_context.get('project_type')
                        if project_type_val:
                            context_for_prompt["Project Type"] = project_type_val

                        # Define mappings from session state keys to descriptive labels
                        new_project_mappings = {
                            'np_target_audience': "Target Audience",
                            'np_core_functionality': "Core Functionality",
                            'np_data_sensitivity': "Data Sensitivity Level",
                            'np_expected_user_volume': "Expected User Volume",
                            'np_performance_needs': "Critical Performance Needs",
                            'np_integration_points': "Key Integration Points",
                            'np_regulatory_compliance': "Regulatory/Compliance Needs",
                            'np_security_concerns': "Major Security Concerns",
                            'np_deployment_env': "Deployment Environment",
                            'np_scalability_needs': "Scalability Requirements"
                        }
                        enhancement_mappings = {
                            'enh_affected_module': "Affected Module/System",
                            'enh_current_limitations': "Current Limitations Being Addressed",
                            'enh_impact_on_existing': "Impact on Existing Functionality",
                            'enh_data_migration': "Data Migration Required?",
                            'enh_performance_impact': "Expected Performance Impact",
                            'enh_security_implications': "Security Implications of Change",
                            'enh_user_impact': "Impact on Users",
                            'enh_dependencies': "Dependencies on Other Systems/Modules",
                            'enh_rollback_plan': "Rollback Plan Exists?",
                            'enh_testing_scope': "Specific Testing Scope for Enhancement"
                        }

                        if project_type_val == 'New Project':
                            for key_prefix, descriptive_label in new_project_mappings.items():
                                session_key = f"ctx_{key_prefix}_sidebar_global" # Construct the actual session state key
                                value = st.session_state.get(session_key) # Get value from session_state
                                if value: # Only add if value exists and is not empty
                                    context_for_prompt[descriptive_label] = value
                        elif project_type_val == 'Enhancement':
                            for key_prefix, descriptive_label in enhancement_mappings.items():
                                session_key = f"ctx_{key_prefix}_sidebar_global" # Construct the actual session state key
                                value = st.session_state.get(session_key) # Get value from session_state
                                if value: # Only add if value exists and is not empty
                                    context_for_prompt[descriptive_label] = value
                        
                        prompt = gpt_logic.compose_prompt(requirement_text, context_for_prompt, st.session_state.similar_requirements)
                        gpt_response = gpt_logic.get_gpt_assessment(prompt, current_api_key)

                        if gpt_response and "error" in gpt_response:
                            st.error(f"Analysis failed: {gpt_response['error']}")
                            st.session_state.assessment_result = None; st.session_state.assessment_id = None
                        elif gpt_response:
                            st.session_state.assessment_result = gpt_response
                            doc_id = chroma_logic.add_assessment(
                                collection, requirement_text, embedding,
                                gpt_response.get('risk'), gpt_response.get('reasoning'),
                                gpt_response.get('recommendations'), gpt_response.get('impact'),
                                st.session_state.current_context.get('project_name', 'N/A')
                            )
                            st.session_state.assessment_id = doc_id
                            if doc_id: st.success("Analysis complete!")
                            else: st.error("Failed to save to database.")
                        else:
                            st.error("Analysis failed. No response."); st.session_state.assessment_result = None; st.session_state.assessment_id = None
                    except Exception as e:
                        st.error(f"Analysis error: {e}"); st.session_state.assessment_result = None; st.session_state.assessment_id = None
    
    if st.session_state.assessment_result and "error" not in st.session_state.assessment_result and input_method != "Bulk Upload (CSV)":
        st.markdown("---"); st.header("Assessment Results (Single)")
        if st.session_state.similar_requirements:
            with st.expander("Similar Past Assessments Found"):
                for sim_req in st.session_state.similar_requirements:
                    meta = sim_req.get('metadata', {})
                    st.markdown(f"**ID:** `{meta.get('id')}` (Similarity: {1-sim_req.get('distance', 1):.2f})")
                    st.markdown(f"**Risk:** {meta.get('risk', 'N/A')}")
                    st.text_area(f"Requirement (similar):", value=meta.get('requirement_text', 'N/A'), height=70, disabled=True, key=f"sim_req_text_disp_{meta.get('id')}")
                    st.markdown("---")

        res = st.session_state.assessment_result
        st.subheader(f"Risk Level: {res.get('risk', 'N/A')}")
        st.markdown(f"**Reasoning:** {res.get('reasoning', 'N/A')}")
        st.markdown(f"**Recommended Testing:** {res.get('recommendations', 'N/A')}")
        st.markdown(f"**Impact of Not Testing:** {res.get('impact', 'N/A')}")
        st.markdown("---"); st.subheader("Architect Review")
        review_comment = st.text_area("Review Comments:", key="review_comment_tab1")
        
        col1_approve, col2_reject = st.columns(2)
        if col1_approve.button("Mark as Approved", key="approve_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global # Consistent usage
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Approved", review_comment)
                    if success: 
                        st.success("Marked as Approved!"); st.session_state.assessment_result['status'] = "Approved"; st.session_state.assessment_result['comments'] = review_comment
                    else: st.error("Failed to update status.")
            else: st.warning("No assessment ID. Run analysis first.")

        if col2_reject.button("Mark as Rejected", key="reject_btn_tab1", use_container_width=True):
            if st.session_state.assessment_id:
                with st.spinner("Updating..."):
                    current_api_key = st.session_state.api_key_input_global # Consistent usage
                    success = chroma_logic.update_assessment_status(chroma_logic.get_or_create_collection(current_api_key), st.session_state.assessment_id, "Rejected", review_comment)
                    if success: 
                        st.success("Marked as Rejected!"); st.session_state.assessment_result['status'] = "Rejected"; st.session_state.assessment_result['comments'] = review_comment
                    else: st.error("Failed to update status.")
            else: st.warning("No assessment ID. Run analysis first.")

        st.markdown("---")
        pdf_report_data = {
            'requirement_text': st.session_state.current_requirement_text,
            'context': st.session_state.current_context, 
            **res,
            'status': st.session_state.assessment_result.get('status', 'Pending'),
            'comments': st.session_state.assessment_result.get('comments', ''),
            'timestamp': int(time.time()), 
            'id': st.session_state.assessment_id or "N/A",
            'project_name': st.session_state.current_context.get('project_name', 'N/A')
        }
        if 'approved' in pdf_report_data: 
            del pdf_report_data['approved']
        pdf_data = pdf_generator.generate_pdf_report(pdf_report_data)
        st.download_button("Download Report as PDF", pdf_data, f"assessment_{st.session_state.assessment_id or 'report'}.pdf", "application/pdf", key="download_pdf_tab1")

    if st.session_state.batch_assessment_results and input_method == "Bulk Upload (CSV)":
        st.markdown("---")
        st.header("Batch Assessment Summary")
        
        # Display batch results in a table
        batch_df = pd.DataFrame(st.session_state.batch_assessment_results)
        st.dataframe(batch_df)
        
        # Provide download button for batch results
        csv_data = batch_df.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download Batch Results as CSV",
            data=csv_data,
            file_name="batch_assessment_results.csv",
            mime="text/csv",
            key="download_batch_csv"
        )
        st.info("Note: To approve/reject or add detailed comments for batch-processed items, please find them in the 'Previous Results' tab using their ID or Project Name.")


with tab2:
    st.header("Past Assessments")
    current_api_key_for_tab2 = st.session_state.get("api_key_input_global") # Consistent usage
    if not current_api_key_for_tab2:
        st.info("Please enter OpenAI API Key in the sidebar to view past assessments.")
    else:
        try:
            collection = chroma_logic.get_or_create_collection(current_api_key_for_tab2)
            all_assessments = chroma_logic.get_all_assessments(collection)

            # --- Ensure all assessments have 'project_name' ---
            for a in all_assessments:
                if 'project_name' not in a or not a['project_name']:
                    a['project_name'] = 'N/A'

            # --- Filtering & Sorting controls moved into Tab 2 main area ---
            st.markdown("#### Filter & Sort Past Assessments")
            filter_cols = st.columns(3)
            with filter_cols[0]:
                filter_project_name_tab2 = st.text_input("Filter by Project Name:", key="filter_project_name_main_tab2")
            with filter_cols[1]:
                filter_risk_level_tab2 = st.multiselect("Filter by Risk Level:", options=["High", "Medium", "Low"], key="filter_risk_level_main_tab2")
            with filter_cols[2]:
                filter_approval_status_tab2 = st.selectbox("Filter by Status:", options=["All", "Pending", "Approved", "Rejected"], index=0, key="filter_approval_status_main_tab2")

            sort_cols = st.columns(2)
            with sort_cols[0]:
                sort_column_tab2 = st.selectbox("Sort by:", options=["Timestamp", "Project Name", "Risk Level", "Approval Status"], key="sort_column_main_tab2")
            with sort_cols[1]:
                sort_ascending_tab2 = st.radio("Sort Order:", options=["Ascending", "Descending"], key="sort_order_main_tab2", horizontal=True) == "Ascending"
            st.markdown("---")

            # --- Debug: Show count of loaded assessments ---
            st.caption(f"Loaded {len(all_assessments)} assessments from database.")

            if not all_assessments:
                st.info("No past assessments found.")
            else:
                assessment_dict = {assessment.get('id'): assessment for assessment in all_assessments}
                
                filtered_assessments = all_assessments
                # --- Defensive: always use .get() and lower() safely ---
                if filter_project_name_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if filter_project_name_tab2.lower() in str(a.get('project_name', '')).lower()
                    ]
                if filter_risk_level_tab2:
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('risk') in filter_risk_level_tab2
                    ]
                if filter_approval_status_tab2 != "All":
                    filtered_assessments = [
                        a for a in filtered_assessments
                        if a.get('status') == filter_approval_status_tab2
                    ]
                
                if filtered_assessments:
                    def get_sort_key_tab2(assessment):
                        val_key = sort_column_tab2.lower().replace(" ", "_")
                        if sort_column_tab2 == "Approval Status": val_key = "status"
                        val = assessment.get(val_key, 0)
                        if isinstance(val, str): return val.lower()
                        if sort_column_tab2 == "Risk Level": return {"Low": 0, "Medium": 1, "High": 2}.get(val, -1)
                        return val # Handles timestamp (int)
                    filtered_assessments.sort(key=get_sort_key_tab2, reverse=not sort_ascending_tab2)

                if not filtered_assessments:
                    st.info("No assessments match current filter criteria.")
                else:
                    st.write(f"Displaying {len(filtered_assessments)} assessment(s):")
                    cols_names_tab2 = ["Project Name", "Risk Level", "Status", "Timestamp", "Details"]
                    header_cols_tab2 = st.columns(len(cols_names_tab2))
                    for col, name in zip(header_cols_tab2, cols_names_tab2): col.markdown(f"**{name}**")
                    st.markdown("---")

                    for assess_data in filtered_assessments:
                        row_cols_tab2 = st.columns(len(cols_names_tab2))
                        row_cols_tab2[0].write(assess_data.get('project_name', 'N/A'))
                        row_cols_tab2[1].write(assess_data.get('risk', 'N/A'))
                        row_cols_tab2[2].write(assess_data.get('status', 'N/A'))
                        row_cols_tab2[3].write(time.strftime('%Y-%m-%d %H:%M', time.localtime(assess_data.get('timestamp', 0))))
                        
                        with row_cols_tab2[4]:
                            details_popover = st.popover("View", use_container_width=True) 
                        
                        with details_popover:
                            full_details = assessment_dict.get(assess_data.get('id'))
                            if full_details:
                                st.markdown(f"#### Details for ID: {full_details.get('id')}")
                                st.markdown(f"**Project:** {full_details.get('project_name', 'N/A')}")
                                st.markdown(f"**Timestamp:** {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(full_details.get('timestamp',0)))}")
                                st.markdown(f"**Risk:** {full_details.get('risk', 'N/A')}")
                                st.markdown(f"**Status:** {full_details.get('status', 'N/A')}")
                                st.markdown(f"**Comments:** {full_details.get('comments', 'None')}")
                                st.markdown("**Requirement:**")
                                st.text_area("req_text_popup_disp", value=full_details.get('requirement_text','N/A'), height=100, disabled=True, key=f"popup_req_disp_{full_details.get('id')}")
                                st.markdown(f"**Reasoning:** {full_details.get('reasoning', 'N/A')}")
                                st.markdown(f"**Recommendations:** {full_details.get('recommendations', 'N/A')}")
                                st.markdown(f"**Impact:** {full_details.get('impact', 'N/A')}")
                                try:
                                    pdf_payload = {**full_details, 'context': {'project_name': full_details.get('project_name', 'N/A')}}
                                    pdf_bytes = pdf_generator.generate_pdf_report(pdf_payload)
                                    st.download_button("Download Report", pdf_bytes, f"assessment_{full_details.get('id')}.pdf", "application/pdf", key=f"dl_popup_btn_{full_details.get('id')}")
                                except Exception as e_pdf: st.error(f"PDF Error: {e_pdf}")
                            else: st.error("Details not found.")
                        st.markdown("---")
        except Exception as e:
            st.error(f"Error loading past assessments: {e}")
            print(f"Error in Tab 2: {e}")

# Add session state to track the number of questions asked
if 'chat_question_count' not in st.session_state:
    st.session_state.chat_question_count = 0  # Initialize question count

# --- Replace the previous chat interface with an improved floating chat interface ---
def show_floating_chat_interface():
    """Displays a chat interface using a floating window in the bottom right corner"""
    # Inject custom CSS for floating chat UI
    st.markdown(
        """
        <style>
        .floating-chat-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 350px;
            height: 500px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-header {
            padding: 15px;
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .chat-messages {
            flex-grow: 1;
            padding: 15px;
            overflow-y: auto;
        }
        .user-message {
            background-color: #DCF8C6;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 10px;
            max-width: 80%;
            align-self: flex-end;
            margin-left: auto;
        }
        .ai-message {
            background-color: #F1F0F0;
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 10px;
            max-width: 80%;
            align-self: flex-start;
        }
        .chat-input-area {
            padding: 15px;
            border-top: 1px solid #E0E0E0;
            display: flex;
        }
        .chat-input-area input {
            flex-grow: 1;
            margin-right: 10px;
            padding: 8px;
            border: 1px solid #E0E0E0;
            border-radius: 5px;
        }
        .send-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
        }
        .close-btn {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
        }
        .question-counter {
            font-size: 12px;
            color: #888;
            margin-top: 5px;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Create floating chat container with HTML/CSS
    chat_html = f"""
    <div class="floating-chat-container" id="chatContainer">
        <div class="chat-header">
            <span>Requirement Enhancement Assistant</span>
            <button class="close-btn" onclick="document.getElementById('closeChat').click();">×</button>
        </div>
        <div class="chat-messages" id="chatMessages">
    """
    
    # Add messages to chat
    for message in st.session_state.chat_messages:
        if message["role"] != "system":
            if message["role"] == "user":
                chat_html += f'<div class="user-message"><b>You:</b> {message["content"]}</div>'
            elif message["role"] == "assistant":
                chat_html += f'<div class="ai-message"><b>AI:</b> {message["content"]}</div>'
    
    # Add question counter
    remaining_questions = 10 - st.session_state.chat_question_count
    chat_html += f'<div class="question-counter">Questions remaining: {remaining_questions}/10</div>'
    
    # Close chat messages div
    chat_html += '</div>'
    
    # Render the custom HTML
    st.markdown(chat_html, unsafe_allow_html=True)
    
    # Create a container for the chat input elements (not visible directly)
    with st.container():
        # Use a unique key for the chat input in the floating interface
        chat_input = st.text_input("Message", key="floating_chat_input", label_visibility="collapsed")
        
        # Hidden buttons that will be triggered by the HTML buttons
        send_clicked = st.button("Send", key="send_floating_chat", help="Send your message", 
                                 disabled=st.session_state.chat_question_count >= 10)
        close_clicked = st.button("Close", key="closeChat")
        
        if send_clicked and chat_input:
            st.session_state.chat_messages.append({"role": "user", "content": chat_input})
            with st.spinner("AI is thinking..."):
                ai_response = get_ai_response(chat_input, st.session_state.api_key_input_global, 
                                              st.session_state.current_requirement_text)
                st.session_state.chat_messages.append({"role": "assistant", "content": ai_response})
                st.session_state.chat_question_count += 1
                
                # Re-evaluate requirement after new messages
                current_conversation_text_for_feedback = generate_enhanced_requirement(st.session_state.api_key_input_global)
                is_sufficient_now, _ = evaluate_requirement_quality(current_conversation_text_for_feedback, 
                                                                   st.session_state.api_key_input_global)
                st.session_state.chat_is_currently_sufficient = is_sufficient_now
                
                # Auto-generate enhanced requirement after 10th question
                if st.session_state.chat_question_count >= 10:
                    with st.spinner("Generating final enhanced requirement..."):
                        enhanced_req = generate_enhanced_requirement(st.session_state.api_key_input_global)
                        st.session_state.enhanced_requirement = enhanced_req
                        st.session_state.manual_text_tab1 = enhanced_req
                        st.session_state.current_requirement_text = enhanced_req
                        st.session_state.requirement_sufficient = True
            st.rerun()
            
        if close_clicked:
            st.session_state.chat_active = False
            st.rerun()

    # Add JavaScript for auto-scrolling chat and input handling
    st.markdown("""
    <script>
        // Auto-scroll chat to bottom
        const messages = document.getElementById('chatMessages');
        if (messages) {
            messages.scrollTop = messages.scrollHeight;
        }
    </script>
    """, unsafe_allow_html=True)

# --- Show chat interface if chat is active ---
if st.session_state.chat_active and input_method == "Enter Text Manually" and st.session_state.api_key_input_global:
    show_floating_chat_interface()  # Use our new floating chat interface

# Determine if analysis button should be enabled
button_disabled = not st.session_state.all_fields_filled
if input_method == "Enter Text Manually":
    # Always enable button if fields filled, regardless of requirement sufficiency
    button_disabled = not st.session_state.all_fields_filled
elif input_method == "Bulk Upload (CSV)":
    if not uploaded_file:  # Disable if no file is uploaded for bulk
        button_disabled = True
elif input_method == "Upload File":
    if not uploaded_file:  # Disable if no file is uploaded for single
        button_disabled = True

# Remove the duplicate show_chat_interface function at the end of the file
# (The original function should be replaced entirely by show_floating_chat_interface)
